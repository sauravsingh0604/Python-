# It is defined for number input.
def numInput():
    print("Enter a number.")
    num = int(input(':- '))
    return num